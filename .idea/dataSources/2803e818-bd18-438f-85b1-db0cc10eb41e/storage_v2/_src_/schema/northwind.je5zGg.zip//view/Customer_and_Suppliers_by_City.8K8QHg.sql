create view `Customer and Suppliers by City` as select `northwind`.`Customers`.`City`        AS `City`,
                                                       `northwind`.`Customers`.`CompanyName` AS `CompanyName`,
                                                       `northwind`.`Customers`.`ContactName` AS `ContactName`,
                                                       'Customers'                           AS `Relationship`
                                                from `northwind`.`Customers`
                                                union
                                                select `northwind`.`Suppliers`.`City`        AS `City`,
                                                       `northwind`.`Suppliers`.`CompanyName` AS `CompanyName`,
                                                       `northwind`.`Suppliers`.`ContactName` AS `ContactName`,
                                                       'Suppliers'                           AS `Suppliers`
                                                from `northwind`.`Suppliers`
                                                order by `City`, `CompanyName`;

