create view `Order Details Extended` as
select `northwind`.`Order Details`.`OrderID`                          AS `OrderID`,
       `northwind`.`Order Details`.`ProductID`                        AS `ProductID`,
       `northwind`.`Products`.`ProductName`                           AS `ProductName`,
       `northwind`.`Order Details`.`UnitPrice`                        AS `UnitPrice`,
       `northwind`.`Order Details`.`Quantity`                         AS `Quantity`,
       `northwind`.`Order Details`.`Discount`                         AS `Discount`,
       ((((`northwind`.`Order Details`.`UnitPrice` * `northwind`.`Order Details`.`Quantity`) *
          (1 - `northwind`.`Order Details`.`Discount`)) / 100) * 100) AS `ExtendedPrice`
from (`northwind`.`Products`
         join `northwind`.`Order Details`
              on ((`northwind`.`Products`.`ProductID` = `northwind`.`Order Details`.`ProductID`)));

