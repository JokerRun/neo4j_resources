create view `Sales by Category` as
select `northwind`.`Categories`.`CategoryID`         AS `CategoryID`,
       `northwind`.`Categories`.`CategoryName`       AS `CategoryName`,
       `northwind`.`Products`.`ProductName`          AS `ProductName`,
       sum(`Order Details Extended`.`ExtendedPrice`) AS `ProductSales`
from (((`northwind`.`Categories` join `northwind`.`Products` on ((`northwind`.`Categories`.`CategoryID` =
                                                                  `northwind`.`Products`.`CategoryID`))) join `northwind`.`Order Details Extended` on ((
        `northwind`.`Products`.`ProductID` = `Order Details Extended`.`ProductID`)))
         join `northwind`.`Orders` on ((`northwind`.`Orders`.`OrderID` = `Order Details Extended`.`OrderID`)))
where (`northwind`.`Orders`.`OrderDate` between '1997-01-01' and '1997-12-31')
group by `northwind`.`Categories`.`CategoryID`, `northwind`.`Categories`.`CategoryName`,
         `northwind`.`Products`.`ProductName`;

