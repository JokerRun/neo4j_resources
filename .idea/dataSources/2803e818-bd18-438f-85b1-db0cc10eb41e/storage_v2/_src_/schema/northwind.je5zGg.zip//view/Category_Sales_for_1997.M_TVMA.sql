create view `Category Sales for 1997` as
select `Product Sales for 1997`.`CategoryName`      AS `CategoryName`,
       sum(`Product Sales for 1997`.`ProductSales`) AS `CategorySales`
from `northwind`.`Product Sales for 1997`
group by `Product Sales for 1997`.`CategoryName`;

