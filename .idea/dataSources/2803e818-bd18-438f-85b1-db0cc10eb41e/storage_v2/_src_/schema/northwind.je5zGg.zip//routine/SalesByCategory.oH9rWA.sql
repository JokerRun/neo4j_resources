create
    definer = root@`%` procedure SalesByCategory()
BEGIN

END;

