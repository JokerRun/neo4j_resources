create view `Sales Totals by Amount` as
select `Order Subtotals`.`Subtotal`          AS `SaleAmount`,
       `northwind`.`Orders`.`OrderID`        AS `OrderID`,
       `northwind`.`Customers`.`CompanyName` AS `CompanyName`,
       `northwind`.`Orders`.`ShippedDate`    AS `ShippedDate`
from ((`northwind`.`Customers` join `northwind`.`Orders` on ((`northwind`.`Customers`.`CustomerID` =
                                                              `northwind`.`Orders`.`CustomerID`)))
         join `northwind`.`Order Subtotals` on ((`northwind`.`Orders`.`OrderID` = `Order Subtotals`.`OrderID`)))
where ((`Order Subtotals`.`Subtotal` > 2500) and
       (`northwind`.`Orders`.`ShippedDate` between '1997-01-01' and '1997-12-31'));

