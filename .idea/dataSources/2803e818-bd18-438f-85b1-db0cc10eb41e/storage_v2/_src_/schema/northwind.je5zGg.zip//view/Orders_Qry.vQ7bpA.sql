create view `Orders Qry` as
select `northwind`.`Orders`.`OrderID`        AS `OrderID`,
       `northwind`.`Orders`.`CustomerID`     AS `CustomerID`,
       `northwind`.`Orders`.`EmployeeID`     AS `EmployeeID`,
       `northwind`.`Orders`.`OrderDate`      AS `OrderDate`,
       `northwind`.`Orders`.`RequiredDate`   AS `RequiredDate`,
       `northwind`.`Orders`.`ShippedDate`    AS `ShippedDate`,
       `northwind`.`Orders`.`ShipVia`        AS `ShipVia`,
       `northwind`.`Orders`.`Freight`        AS `Freight`,
       `northwind`.`Orders`.`ShipName`       AS `ShipName`,
       `northwind`.`Orders`.`ShipAddress`    AS `ShipAddress`,
       `northwind`.`Orders`.`ShipCity`       AS `ShipCity`,
       `northwind`.`Orders`.`ShipRegion`     AS `ShipRegion`,
       `northwind`.`Orders`.`ShipPostalCode` AS `ShipPostalCode`,
       `northwind`.`Orders`.`ShipCountry`    AS `ShipCountry`,
       `northwind`.`Customers`.`CompanyName` AS `CompanyName`,
       `northwind`.`Customers`.`Address`     AS `Address`,
       `northwind`.`Customers`.`City`        AS `City`,
       `northwind`.`Customers`.`Region`      AS `Region`,
       `northwind`.`Customers`.`PostalCode`  AS `PostalCode`,
       `northwind`.`Customers`.`Country`     AS `Country`
from (`northwind`.`Customers`
         join `northwind`.`Orders` on ((`northwind`.`Customers`.`CustomerID` = `northwind`.`Orders`.`CustomerID`)));

